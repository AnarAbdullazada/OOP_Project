/**
 * The Client class represents a client application that allows users to select destinations and submit their choices to a server.
 * The destinations are displayed as tiles with an image and buttons for rating them.
 *
 * @version 1.0
 * @since 2023-05-15
 */

import java.awt.*;
import java.awt.event.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.swing.*;
import java.net.*;

class Client {
    private static int[] database = new int[11];

    private static void run() {
        JFrame frame = new JFrame("Client Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        for (int i = 1; i <= 10; i++) {
            final int finalI = i; // define a final copy of i
            JPanel tilePanel = new JPanel(new BorderLayout(5, 5));
            tilePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

            JLabel textLabel = new JLabel("Destination " + i, SwingConstants.CENTER);
            textLabel.setFont(new Font("Arial", Font.BOLD, 16));
            tilePanel.add(textLabel, BorderLayout.NORTH);

            ImageIcon icon = new ImageIcon("./assets/"+ i + ".png");
            JLabel imageLabel = new JLabel(icon, SwingConstants.CENTER);
            tilePanel.add(imageLabel, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 5, 5));
            for (int j = 1; j <= 5; j++) {
                JButton button = new JButton(j + " ★");
                button.addActionListener(new ActionListener() {
                    int pressedIndex = -1;

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int thisIndex = buttonPanel.getComponentZOrder(button);
                        if (pressedIndex == thisIndex) {
                            button.setBackground(UIManager.getColor("Button.background"));
                            pressedIndex = -1;
                        } else {
                            button.setBackground(Color.YELLOW);
                            for (int a = 0; a < thisIndex; a++) {
                                ((JButton) buttonPanel.getComponent(a)).setBackground(Color.YELLOW);
                            }
                            for (int a = thisIndex + 1; a < 5; a++) {
                                ((JButton) buttonPanel.getComponent(a))
                                        .setBackground(UIManager.getColor("Button.background"));
                            }
                            pressedIndex = thisIndex;
                        }
                        // print destination and button pressed
                        System.out.println(
                                "Destination " + finalI + " , Button " + button.getText().substring(0, 1) + " pressed");
                        database[finalI] = Integer.parseInt(button.getText().substring(0, 1));
                    }
                });
                buttonPanel.add(button);
            }
            tilePanel.add(buttonPanel, BorderLayout.SOUTH);
            panel.add(tilePanel);
        }

        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        submitButton.setForeground(Color.WHITE);
        submitButton.setBackground(Color.gray);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // handle submit button click event here
                for (int i = 0; i < 11; i++)
                    System.out.println("array index " + i + " , value " + database[i]);
                connect();
            }
        });

        JPanel submitPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        submitPanel.add(submitButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(panel, BorderLayout.CENTER);
        mainPanel.add(submitPanel, BorderLayout.SOUTH);

        frame.add(mainPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static void connect() {
        try {
            // Create a socket to connect to the server
            Socket socket = new Socket("localhost", 8080);

            // Create an output stream to send data to the server
            OutputStream outputStream = socket.getOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

            // Write the database array to the output stream
            for (int i = 0; i < database.length; i++) {
                dataOutputStream.writeInt(database[i]);
            }

            // Close the output stream and socket
            dataOutputStream.close();
            socket.close();

            // Print a message to indicate that the data was sent successfully
            System.out.println("Data sent successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        run();
    }
}
