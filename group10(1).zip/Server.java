/**
 * The Server class represents a server application that receives rating choices from clients and evaluates the best destinations.
 * It displays the received choices and performs the evaluation.
 *
 * @version 1.0
 * @since 2023-05-15
 */

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import javax.swing.*;

class Server extends JFrame {
    private ArrayList<int[]> alldatabase = new ArrayList<int[]>();
    private int[] database = new int[11];
    private JTextArea textArea;

    private void evaluate(ArrayList<int[]> alldatabase2) {
        int[] destinationCounts = new int[11]; // Array to keep track of user counts per destination

        for (int[] userRating : alldatabase2) {
            int userId = userRating[0];
            int bestDestination = -1;
            int highestRating = Integer.MIN_VALUE;

            // Iterate over the destination ratings for the current user
            for (int i = 1; i < userRating.length; i++) {
                int destinationRating = userRating[i];

                // Check if the current destination rating is higher than the previous highest
                // rating
                if (destinationRating > highestRating) {
                    highestRating = destinationRating;
                    bestDestination = i;
                }
            }

            // Check if the best destination has reached the 4-user limit
            if (bestDestination != -1 && destinationCounts[bestDestination] >= 4) {
                int nextBestDestination = -1;
                int nextHighestRating = Integer.MIN_VALUE;

                // Find the next available destination with the highest rating and less than 4
                // users
                for (int i = 1; i < userRating.length; i++) {
                    if (destinationCounts[i] < 4 && userRating[i] > nextHighestRating) {
                        nextHighestRating = userRating[i];
                        nextBestDestination = i;
                    }
                }

                // Assign the next best destination if available
                if (nextBestDestination != -1) {
                    bestDestination = nextBestDestination;
                    highestRating = nextHighestRating;
                }
            }

            // Update the user count for the selected destination
            if (bestDestination != -1) {
                destinationCounts[bestDestination]++;
                System.out.println("User " + userId + ": Best Destination = Dest" + bestDestination);
            } else {
                System.out.println("User " + userId + ": No available destination found.");
            }
        }
    }

    public Server() {
        super("Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a text area to display the contents of the list
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Create a button to trigger evaluation
        JButton evaluateButton = new JButton("Evaluate");
        evaluateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evaluate(alldatabase);
            }
        });

        // Add the components to the frame
        JPanel panel = new JPanel();
        panel.add(evaluateButton);
        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Resize and display the frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void start() {
        try {
            // Create a server socket to listen for incoming connections on port 8080
            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Server started");

            // Listen for incoming connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected " + clientSocket.getPort());

                // Create an input stream to read data from the client
                InputStream inputStream = clientSocket.getInputStream();
                DataInputStream dataInputStream = new DataInputStream(inputStream);

                // Read the database array from the input stream
                for (int i = 0; i < database.length; i++) {
                    database[i] = dataInputStream.readInt();
                }

                database[0] = clientSocket.getPort();
                // Print the contents of the list
                alldatabase.add(database.clone());
                StringBuilder sb = new StringBuilder();
                for (int[] array : alldatabase) {
                    for (int value : array) {
                        sb.append(value).append(" ");
                    }
                    sb.append("\n");
                }
                textArea.setText(sb.toString());

                // Close the input stream and socket
                dataInputStream.close();
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Server().start();
    }
}
